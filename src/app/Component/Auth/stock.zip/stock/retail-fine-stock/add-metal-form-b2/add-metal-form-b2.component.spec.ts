import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AddMetalFormB2Component } from './add-metal-form-b2.component';
import { provideRouter } from '@angular/router';

describe('AddMetalFormB2Component', () => {
  let component: AddMetalFormB2Component;
  let fixture: ComponentFixture<AddMetalFormB2Component>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [AddMetalFormB2Component],
      providers: [
        provideRouter([])
      ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(AddMetalFormB2Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
