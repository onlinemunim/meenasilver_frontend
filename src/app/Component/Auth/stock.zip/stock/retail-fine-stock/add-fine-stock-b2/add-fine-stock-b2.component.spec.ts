import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AddFineStockB2Component } from './add-fine-stock-b2.component';
import { provideRouter } from '@angular/router';

describe('AddFineStockB2Component', () => {
  let component: AddFineStockB2Component;
  let fixture: ComponentFixture<AddFineStockB2Component>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [AddFineStockB2Component],
      providers: [
        provideRouter([])
      ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(AddFineStockB2Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
