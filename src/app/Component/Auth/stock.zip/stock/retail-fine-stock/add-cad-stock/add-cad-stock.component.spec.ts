import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AddCadStockComponent } from './add-cad-stock.component';
import { provideRouter } from '@angular/router';

describe('AddCadStockComponent', () => {
  let component: AddCadStockComponent;
  let fixture: ComponentFixture<AddCadStockComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [AddCadStockComponent],
      providers: [
        provideRouter([])
      ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(AddCadStockComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
