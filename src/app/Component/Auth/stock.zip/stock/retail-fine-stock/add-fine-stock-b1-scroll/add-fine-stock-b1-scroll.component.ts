import { Component, OnInit } from '@angular/core';
import { CustomSelectComponent } from '../../../../Core/custom-select/custom-select.component';
import { initFlowbite } from 'flowbite';
import { RouterLink, RouterLinkActive } from '@angular/router';
import { NgFor } from '@angular/common';

@Component({
  selector: 'app-add-fine-stock-b1-scroll',
  standalone: true,
  imports: [CustomSelectComponent, RouterLink, RouterLinkActive, NgFor],
  templateUrl: './add-fine-stock-b1-scroll.component.html',
  styleUrl: './add-fine-stock-b1-scroll.component.css'
})
export class AddFineStockB1ScrollComponent implements OnInit{

   ngOnInit(): void {
    initFlowbite();
  }

  stoneForms: number[] = [];
  private nextFormId = 0;

  addStoneForm() {
    this.stoneForms.push(this.nextFormId++);
  }

  removeStoneForm(id: number) {
    this.stoneForms = this.stoneForms.filter(formId => formId !== id);
  }

 // for Firm
  firmTypes: string[] = ['firm 1', 'firm 2', 'firm 3', 'firm 4'];
  selectedFirm: string = '';

 // for brand/seller Name
  brandSeller: string[] = [''];
  selectedBrandseller: string = '';

}
