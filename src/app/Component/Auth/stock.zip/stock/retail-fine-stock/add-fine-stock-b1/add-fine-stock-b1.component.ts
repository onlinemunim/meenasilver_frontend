import { Component, OnInit } from '@angular/core';
import { CustomSelectComponent } from '../../../../Core/custom-select/custom-select.component';
import { initFlowbite } from 'flowbite';
import { RouterLink, RouterLinkActive } from '@angular/router';
import { NgFor, NgIf } from '@angular/common';
import { StoneFormComponent } from '../../stone-form/stone-form.component';
import { FormBuilder, FormGroup, ReactiveFormsModule } from '@angular/forms';
import { FirmService } from '../../../../../Services/firm.service';
import { StockService } from '../../../../../Services/Stock/stock.service';
import { NotificationService } from '../../../../../Services/notification.service';

@Component({
  selector: 'app-add-fine-stock-b1',
  standalone: true,
  imports: [
    CustomSelectComponent,
    RouterLink,
    RouterLinkActive,
    NgIf,
    StoneFormComponent,
    ReactiveFormsModule,
    NgFor,
  ],
  templateUrl: './add-fine-stock-b1.component.html',
  styleUrl: './add-fine-stock-b1.component.css',
})
export class AddFineStockB1Component implements OnInit {
  fineStockForm!: FormGroup;

  constructor(
    private fb: FormBuilder,
    private firmService: FirmService,
    private stockService: StockService,
    private notificationService:NotificationService
  ) {}

  ngOnInit(): void {
    this.initFineStockForm();
    this.loadFirmList();
    initFlowbite();
  }

  initFineStockForm() {
    this.fineStockForm = this.fb.group({
      st_item_code: [''],
      st_bill_date: [''],
      st_mfd_date: [''],
      st_firm_id: [''],
      st_brand_seller_name: [''],
      st_metal_type: ['Silver'],
      st_metal_rate: [''],
      st_pre_id: [''],
      st_post_id: [''],
      st_hsn_code: [''],
      st_item_category: [''],
      st_item_name: [''],
      st_huid: [''],
      st_item_model_no: [''],
      st_item_size: [''],
      st_item_length: [''],
      st_color: [''],
      st_barcode: [''],
      st_rfid_number: [''],
      st_quantity: [''],
      st_gs_weight: [''],
      st_less_weight: [''],
      st_pkt_weight: [''],
      st_net_weight: [''],
      st_net_weight_type: ['GM'],
      st_purity: [''],
      st_wastage: [''],
      st_cust_weight: [''],
      st_cust_wastage_weight: [''],
      st_final_purity: [''],
      st_tag_weight: [''],
      st_counter_name: [''],
      st_location: [''],
      st_fine_weight: [''],
      st_final_fine_weight: [''],
      st_making_charges: [''],
      st_making_charges_type: ['GM'],
      st_valuation: [''],
      st_lab_charges: [''],
      st_lab_charges_type: ['GM'],
      st_total_lab_charges: [''],
      st_hm_charges: [''],
      st_hm_charges_type: ['GM'],
      st_total_hm_charges: [''],
      st_other_charges: [''],
      st_other_charges_type: ['GM'],
      st_total_other_charges: [''],
      st_tax: [''],
      st_total_tax: [''],
      st_total_taxable_amt: [''],
      st_bis_hallmark: [''],
      st_add_details: [''],
      st_add_ecom: [''],
      st_fix_mrp: [''],
      st_final_valuation: [''],
      st_type: ['retail'],
    });

    // Subscribe to changes in st_pre_id and st_post_id
    this.fineStockForm.get('st_pre_id')?.valueChanges.subscribe(() => {
      this.updateItemCode();
    });

    this.fineStockForm.get('st_post_id')?.valueChanges.subscribe(() => {
      this.updateItemCode();
    });
  }

  // Method to update st_item_code based on st_pre_id and st_post_id
  updateItemCode(): void {
    const pre = this.fineStockForm.get('st_pre_id')?.value || '';
    const post = this.fineStockForm.get('st_post_id')?.value || '';
    this.fineStockForm
      .get('st_item_code')
      ?.setValue(pre + post, { emitEvent: false });
  }

  onSubmit() {
    // Normalize date fields to 'YYYY-MM-DD'
    ['st_bill_date', 'st_mfd_date'].forEach((field) => {
      const val = this.fineStockForm.get(field)?.value;

      if (val instanceof Date) {
        this.fineStockForm.get(field)?.setValue(val.toISOString().split('T')[0]);
      } else if (typeof val === 'string' && val.includes('T')) {
        this.fineStockForm.get(field)?.setValue(val.split('T')[0]);
      }
    });

    // Now submit the form
    this.stockService.createStockEntry(this.fineStockForm.value).subscribe(
      (res) => {
        console.log('Success:', res.data);
        this.notificationService.showSuccess('Fine Stock Entry Created Successfully!', 'Success');
        this.clearForm();
      },
      (error) => {
        console.error('Error:', error);
        this.notificationService.showError('Failed to create Fine Stock Entry', 'Error');
      }
    );
  }


  clearForm(){
    this.fineStockForm.reset({
      st_metal_type: 'Silver',
      st_net_weight_type: 'GM',
      st_lab_charges_type: 'GM',
      st_hm_charges_type: 'GM',
      st_other_charges_type: 'GM',
      st_making_charges_type: 'GM',
      st_type: 'retail',
    })
  }

  isFormVisible: boolean = false;
  toggleForm() {
    this.isFormVisible = !this.isFormVisible;
  }

  // for Firm
  firmTypes: { id: number; name: string }[] = [];

  loadFirmList() {
    this.firmService.getFirms().subscribe((res: any) => {
      this.firmTypes = res.data;
      console.log('Firms from backend:', this.firmTypes);
    });
  }

  // for brand/seller Name
  brandSeller: string[] = [''];
  selectedBrandseller: string = '';

  // for metal types
  metalTypes: string[] = ['Gold'];
  selectedMetal: string = '';

  // for Item Category
  itemCategory: string[] = ['Ring'];
  selectedItem: string = '';

  // for Size
  sizeRange: string[] = ['10 X 10'];
  selectedSize: string = '';

  // for Color
  colorTypes: string[] = ['White'];
  selectedColor: string = '';

  // for unit
  unitTypes: string[] = ['GM', 'KG', 'MG'];
  selectedUnit: string = '';
  selectedNetWeightUnit: string = '';
  selectedMakingChargesUnit: string = '';
  selectedLabChargesUnit: string = '';
  selectedHMChargesUnit: string = '';
  selectedOtherChargesUnit: string = '';
}
