import { Component, OnInit } from '@angular/core';
import { CustomSelectComponent } from '../../../../Core/custom-select/custom-select.component';
import { initFlowbite } from 'flowbite';
import { RouterLink, RouterLinkActive } from '@angular/router';
import { NgIf } from '@angular/common';
import { StoneFormComponent } from './../../stone-form/stone-form.component';

@Component({
  selector: 'app-add-fine-stock-b3',
  standalone: true,
  imports: [CustomSelectComponent, RouterLink, RouterLinkActive, NgIf, StoneFormComponent],
  templateUrl: './add-fine-stock-b3.component.html',
  styleUrl: './add-fine-stock-b3.component.css'
})
export class AddFineStockB3Component implements OnInit{

   ngOnInit(): void {
    initFlowbite();
  }

  isFormVisible: boolean = false;
  toggleForm() {
    this.isFormVisible = !this.isFormVisible;
  }

 // for Firm
  firmTypes: string[] = ['firm 1', 'firm 2', 'firm 3', 'firm 4'];
  selectedFirm: string = '';

 // for brand/seller Name
  brandSeller: string[] = [''];
  selectedBrandseller: string = '';

 // for metal types
  metalTypes: string[] = ['Gold'];
  selectedMetal: string = '';

 // for Item Category
  itemCategory: string[] = ['Ring'];
  selectedItem: string = '';

 // for unit
  unitTypes: string[] = ['GM'];
  selectedUnit: string = '';

}
