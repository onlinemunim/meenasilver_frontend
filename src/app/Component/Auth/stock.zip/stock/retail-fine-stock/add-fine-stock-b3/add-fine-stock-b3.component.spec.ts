import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AddFineStockB3Component } from './add-fine-stock-b3.component';
import { provideRouter } from '@angular/router';

describe('AddFineStockB3Component', () => {
  let component: AddFineStockB3Component;
  let fixture: ComponentFixture<AddFineStockB3Component>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [AddFineStockB3Component],
      providers: [
        provideRouter([])
      ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(AddFineStockB3Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
