import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AddWholesaleStockB1Component } from './add-wholesale-stock-b1.component';
import { provideRouter } from '@angular/router';

describe('AddWholesaleStockB1Component', () => {
  let component: AddWholesaleStockB1Component;
  let fixture: ComponentFixture<AddWholesaleStockB1Component>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [AddWholesaleStockB1Component],
      providers: [
        provideRouter([])
      ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(AddWholesaleStockB1Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
