import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AddWholesaleStockB2Component } from './add-wholesale-stock-b2.component';
import { provideRouter } from '@angular/router';

describe('AddWholesaleStockB2Component', () => {
  let component: AddWholesaleStockB2Component;
  let fixture: ComponentFixture<AddWholesaleStockB2Component>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [AddWholesaleStockB2Component],
      providers: [
        provideRouter([])
      ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(AddWholesaleStockB2Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
