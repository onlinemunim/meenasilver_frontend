import { NgClass, NgFor, NgIf } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, ReactiveFormsModule } from '@angular/forms';
import { ActivatedRoute, RouterLink } from '@angular/router';
import { StockGeneralService } from '../../../../Services/Product_Creation/stock-general.service';

@Component({
  selector: 'app-order-creation',
  imports: [NgFor,NgClass,NgIf,ReactiveFormsModule],
  templateUrl: './order-creation.component.html',
  styleUrl: './order-creation.component.css'
})
export class OrderCreationComponent implements OnInit {
onImageUpload($event: Event) {
throw new Error('Method not implemented.');
}

ordercreationForm!: FormGroup;
submitbutton: boolean = true;
updatebutton: boolean = false;
filteredProductCodes: any;
showDropdown: any;
activeIndex: any;
previewImage: any;
productCodes: any[] = [];

constructor(private fb: FormBuilder,private stockgenralservice: StockGeneralService )
{}

ngOnInit(): void
{


  this.loadProductCodes();
  this.initform();

}

loadProductCodes(): void {
  this.stockgenralservice.getGeneralProductCodeForProductDesign().subscribe({
    next: (res: any) => {
      this.productCodes = res.data || res || []; // depends on your backend structure
      console.log("this is fetched product",this.productCodes);
    },
    error: () => {
      this.productCodes = [];
    }
  });
}

initform()
{
this.ordercreationForm = this.fb.group({
      st_item_name: '',
      st_item_code: '',
      product_image: '',
      st_quantity: '',
      st_assignee: ''
});

}


onProductCodeInput(): void {
  const code = this.ordercreationForm.get('st_item_code')?.value || '';

  this.filteredProductCodes = this.productCodes.filter(item =>
    item.unique_code_sku && item.unique_code_sku.toLowerCase().includes(code.toLowerCase())
  );

  this.showDropdown = this.filteredProductCodes.length > 0;
}




fetchProductImage(code : string): void
{
  this.stockgenralservice.getProductImageByCode(code).subscribe({
    next: (response: any) => {

      this.previewImage = response.image_url || null;
    },
    error: () => {
      this.previewImage = null; // fallback if not found
    }
  });
}

editpackage()
{

}
onSubmit()
{

}
focusNext(event: Event)
{

}
onKeyDown(event: KeyboardEvent) {
  if (event.key === 'Enter') {
    event.preventDefault();
    this.onSubmit();
  }

}

onInputFocus(): void {
  this.onProductCodeInput(); // Refresh dropdown
}


selectProductCode(item: any): void {
  // Patch form fields
  this.ordercreationForm.patchValue({
    st_item_code: item.unique_code_sku || '',
    st_item_name: item.product_name || '',
    st_quantity: item.quantity || '',
    st_assignee: item.assignee || ''
  });

  // Close dropdown
  this.showDropdown = false;


  if (item.product_image) {
    // If it's already a full URL or starts with /storage/
    this.previewImage = item.product_image.startsWith('http')
      ? item.product_image
      : `http://localhost:9000/${item.product_image}`;
  } else {
    this.previewImage = null;
  }
}


hideDropdownDelayed()
{

}
}
