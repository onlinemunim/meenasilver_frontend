// import { ComponentFixture, TestBed } from '@angular/core/testing';

// import { AddReadyProductComponent } from './add-ready-product.component';

// describe('AddReadyProductComponent', () => {
//   let component: AddReadyProductComponent;
//   let fixture: ComponentFixture<AddReadyProductComponent>;

//   beforeEach(async () => {
//     await TestBed.configureTestingModule({
//       imports: [AddReadyProductComponent]
//     })
//     .compileComponents();

//     fixture = TestBed.createComponent(AddReadyProductComponent);
//     component = fixture.componentInstance;
//     fixture.detectChanges();
//   });

//   it('should create', () => {
//     expect(component).toBeTruthy();
//   });
// });
