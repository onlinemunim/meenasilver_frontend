// import { ComponentFixture, TestBed } from '@angular/core/testing';

// import { ReadyProductListComponent } from './ready-product-list.component';

// describe('ReadyProductListComponent', () => {
//   let component: ReadyProductListComponent;
//   let fixture: ComponentFixture<ReadyProductListComponent>;

//   beforeEach(async () => {
//     await TestBed.configureTestingModule({
//       imports: [ReadyProductListComponent]
//     })
//     .compileComponents();

//     fixture = TestBed.createComponent(ReadyProductListComponent);
//     component = fixture.componentInstance;
//     fixture.detectChanges();
//   });

//   it('should create', () => {
//     expect(component).toBeTruthy();
//   });
// });
