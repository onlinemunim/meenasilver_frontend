import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ImitationStockB3Component } from './imitation-stock-b3.component';

describe('ImitationStockB3Component', () => {
  let component: ImitationStockB3Component;
  let fixture: ComponentFixture<ImitationStockB3Component>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [ImitationStockB3Component]
    })
    .compileComponents();

    fixture = TestBed.createComponent(ImitationStockB3Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
