import { Component } from '@angular/core';

@Component({
  selector: 'app-imitation-stock-b3',
  imports: [],
  templateUrl: './imitation-stock-b3.component.html',
  styleUrl: './imitation-stock-b3.component.css'
})
export class ImitationStockB3Component {

}
