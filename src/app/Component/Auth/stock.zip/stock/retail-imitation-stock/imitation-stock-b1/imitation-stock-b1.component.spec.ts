import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ImitationStockB1Component } from './imitation-stock-b1.component';
import { provideRouter } from '@angular/router';

describe('ImitationStockB1Component', () => {
  let component: ImitationStockB1Component;
  let fixture: ComponentFixture<ImitationStockB1Component>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [ImitationStockB1Component],
      providers: [
        provideRouter([])
      ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(ImitationStockB1Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
