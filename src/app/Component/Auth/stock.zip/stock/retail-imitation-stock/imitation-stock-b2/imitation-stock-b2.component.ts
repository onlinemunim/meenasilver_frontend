import { Component, OnInit } from '@angular/core';
import { CustomSelectComponent } from '../../../../Core/custom-select/custom-select.component';
import { initFlowbite } from 'flowbite';
import { RouterLink, RouterLinkActive } from '@angular/router';
import { NgIf } from '@angular/common';
import { StoneFormComponent } from './../../stone-form/stone-form.component';

@Component({
  selector: 'app-imitation-stock-b2',
  imports: [CustomSelectComponent, RouterLink, RouterLinkActive, StoneFormComponent, NgIf],
  templateUrl: './imitation-stock-b2.component.html',
  styleUrl: './imitation-stock-b2.component.css'
})
export class ImitationStockB2Component  implements OnInit{

ngOnInit(): void {
    initFlowbite();
  }

  isFormVisible: boolean = false;
  toggleForm() {
    this.isFormVisible = !this.isFormVisible;
  }

 // for Item Category
  itemCategory: string[] = ['Ring'];
  selectedItem: string = '';

 // for gender
  genderType: string[] = ['Male', 'Female', 'Kids', 'Unisex'];
  selectedGender: string = '';

 // for unit
  unitTypes: string[] = ['GM'];
  selectedUnit: string = '';

}

