import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ImitationStockB2Component } from './imitation-stock-b2.component';
import { provideRouter } from '@angular/router';

describe('ImitationStockB2Component', () => {
  let component: ImitationStockB2Component;
  let fixture: ComponentFixture<ImitationStockB2Component>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [ImitationStockB2Component],
      providers: [
        provideRouter([])
      ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(ImitationStockB2Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
